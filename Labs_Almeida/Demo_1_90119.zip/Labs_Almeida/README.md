# SCDTR - Demonstration 1

## Author: [João Tiago Almeida](https://github.com/Joao-Tiago-Almeida)
## IST id: 90119
## Group: 1

### November 2020

This part is separated in two folders:
1. [Controller](./controller) contains the part of the PID controller and its [README](./controller/README.md).
2. [ldr_fit](./ldr_fit) where Arduino's constants are computed and its [README](./ldr_fit/README.md).

For local reading, it is suggested to open all README files in a Markdown preview.
